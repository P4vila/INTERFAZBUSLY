package VENATANA;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;
import javax.swing.border.CompoundBorder;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VENATANA_FRAME extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VENATANA_FRAME frame = new VENATANA_FRAME();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VENATANA_FRAME() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 674, 606);
		contentPane = new JPanel();
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0)));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(new Color(176, 214, 247));
		panel2.setBounds(0, 37, 660, 558);
		panel2.setLayout(null);
		panel2.setBorder(new LineBorder(new Color(0, 0, 0)));
		contentPane.add(panel2);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(252, 251, 226));
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(10, 401, 640, 116);
		panel2.add(panel);
		panel.setLayout(null);
		
		JLabel LabelPrecios = new JLabel("Lista de Precios");
		LabelPrecios.setBounds(10, 21, 99, 23);
		LabelPrecios.setVerticalAlignment(SwingConstants.TOP);
		panel.add(LabelPrecios);
		
		JLabel LabelAsociado = new JLabel("Funcionario Asociado");
		LabelAsociado.setBounds(10, 46, 142, 23);
		panel.add(LabelAsociado);
		
		JLabel LabelRubro = new JLabel("Rubro");
		LabelRubro.setBounds(10, 80, 99, 25);
		panel.add(LabelRubro);
		
		textField = new JTextField();
		textField.setBounds(162, 18, 96, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(162, 47, 96, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(162, 82, 96, 20);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel LabelDescuento = new JLabel("Descuento");
		LabelDescuento.setBounds(333, 17, 99, 23);
		panel.add(LabelDescuento);
		
		JLabel LabelLinea = new JLabel("Linea");
		LabelLinea.setBounds(333, 50, 49, 14);
		panel.add(LabelLinea);
		
		JLabel LabelGeneral = new JLabel("General");
		LabelGeneral.setBounds(333, 85, 49, 14);
		panel.add(LabelGeneral);
		
		textField_8 = new JTextField();
		textField_8.setBounds(382, 47, 33, 20);
		panel.add(textField_8);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(425, 47, 33, 20);
		panel.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(468, 47, 33, 20);
		panel.add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBounds(511, 47, 33, 20);
		panel.add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setColumns(10);
		textField_12.setBounds(382, 82, 96, 20);
		panel.add(textField_12);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(252, 251, 226));
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(10, 61, 640, 334);
		panel2.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel LabelNombre = new JLabel("Nombre");
		LabelNombre.setBounds(10, 11, 49, 14);
		panel_1.add(LabelNombre);
		
		JLabel LabelSocial = new JLabel("Razón Social");
		LabelSocial.setBounds(10, 36, 113, 14);
		panel_1.add(LabelSocial);
		
		JLabel LabelDocumento = new JLabel("Documento");
		LabelDocumento.setBounds(10, 61, 113, 14);
		panel_1.add(LabelDocumento);
		
		JLabel LabelDireccion = new JLabel("Dirección");
		LabelDireccion.setBounds(10, 90, 113, 14);
		panel_1.add(LabelDireccion);
		
		textField_4 = new JTextField();
		textField_4.setBounds(92, 87, 96, 20);
		panel_1.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(92, 8, 96, 20);
		panel_1.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(92, 33, 96, 20);
		panel_1.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(203, 62, 96, 20);
		panel_1.add(textField_7);
		textField_7.setColumns(10);
		
		JLabel LabelCiudad = new JLabel("Ciudad");
		LabelCiudad.setBounds(10, 151, 54, 14);
		panel_1.add(LabelCiudad);
		
		JLabel LabelPais = new JLabel("Pais");
		LabelPais.setBounds(10, 115, 113, 14);
		panel_1.add(LabelPais);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(92, 115, 101, 22);
		panel_1.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(92, 61, 101, 22);
		panel_1.add(comboBox_1);
		
		JLabel LabelPostal = new JLabel("Código Postal");
		LabelPostal.setBounds(10, 179, 113, 14);
		panel_1.add(LabelPostal);
		
		JCheckBox CheckBoxCuentaBanco = new JCheckBox("Cuenta Genérica ");
		CheckBoxCuentaBanco.setBounds(10, 231, 132, 23);
		panel_1.add(CheckBoxCuentaBanco);
		
		JLabel LabelContacto = new JLabel("Contactos");
		LabelContacto.setBounds(339, 11, 65, 14);
		panel_1.add(LabelContacto);
		
		JLabel Labeltelefonos = new JLabel("Teléfonos");
		Labeltelefonos.setBounds(339, 90, 65, 14);
		panel_1.add(Labeltelefonos);
		
		JLabel LabelEmail = new JLabel("Email");
		LabelEmail.setBounds(339, 190, 65, 14);
		panel_1.add(LabelEmail);
		
		textField_13 = new JTextField();
		textField_13.setColumns(10);
		textField_13.setBounds(92, 148, 96, 20);
		panel_1.add(textField_13);
		
		textField_14 = new JTextField();
		textField_14.setColumns(10);
		textField_14.setBounds(92, 176, 96, 20);
		panel_1.add(textField_14);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(415, 6, 215, 69);
		panel_1.add(textArea);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(414, 85, 215, 69);
		panel_1.add(textArea_1);
		
		JTextArea textArea_2 = new JTextArea();
		textArea_2.setBounds(415, 174, 215, 69);
		panel_1.add(textArea_2);
		
		JLabel lblNewLabel_5 = new JLabel("Código");
		lblNewLabel_5.setBounds(10, 11, 65, 14);
		panel2.add(lblNewLabel_5);
		
		textField_3 = new JTextField();
		textField_3.setBounds(54, 8, 96, 20);
		panel2.add(textField_3);
		textField_3.setColumns(10);
		
		JCheckBox CheckBox = new JCheckBox("Activo");
		CheckBox.setBounds(160, 7, 99, 23);
		panel2.add(CheckBox);
		
		JLabel lblNewLabel_6 = new JLabel("Datos del Cliente");
		lblNewLabel_6.setBounds(10, 36, 110, 14);
		panel2.add(lblNewLabel_6);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBackground(new Color(211, 210, 255));
		btnCancelar.setBounds(173, 0, 89, 26);
		contentPane.add(btnCancelar);
		
		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			}
			
			
		});
		btnGuardar.setBackground(new Color(211, 210, 255));
		btnGuardar.setBounds(53, 0, 89, 26);
		contentPane.add(btnGuardar);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\HP\\Downloads\\icons8-casilla-de-verificación-marcada-30.png"));
		lblNewLabel.setBounds(23, 0, 36, 26);
		contentPane.add(lblNewLabel);
	}
}
