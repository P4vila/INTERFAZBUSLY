/**
 * 
 */
/**
 * 
 */
module INTERFAZ_TAREA {
	requires java.desktop;
}